(() => {
  try { SEESUM_VIEWER_CORE.connectorToken(location.href); }
  catch { return; }
  const status = document.getElementById("status");
  if (status) status.textContent = "SEESUM Revit 애드인과 연결하는 중입니다...";
  chrome.runtime.sendMessage({ type: "seesum-connect", url: location.href }, response => {
    if (!status) return;
    if (chrome.runtime.lastError) {
      status.textContent = `확장 프로그램 연결 실패: ${chrome.runtime.lastError.message}`;
      return;
    }
    status.textContent = response?.message || "Autodesk Viewer 작업을 시작했습니다. 이 탭은 닫아도 됩니다.";
  });
})();
