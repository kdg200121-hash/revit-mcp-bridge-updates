globalThis.SEESUM_VIEWER_CONFIG = Object.freeze({
  viewerUrl: "https://viewer.autodesk.com/",
  accountUrl: "https://accounts.autodesk.com/",
  allowedViewerHosts: Object.freeze(["autodesk.com"]),
  signingPublicKeySpkiBase64: "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEnA/Slr9IScpX2m3rxPDaPycOCNsj9TFxEdg8E8/Y/Zr3RdcYUyJV4j/cPSlWePl+7MZB7Yu2Fo+Yzd/CcNYpPA==",
});
