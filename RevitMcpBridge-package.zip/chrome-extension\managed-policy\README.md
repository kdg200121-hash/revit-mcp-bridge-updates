# 관리형 브라우저 배포

이 폴더의 JSON은 회사 관리자가 Chrome Enterprise 또는 Microsoft Edge 정책에 옮겨 넣기 위한 예시다. 고정 확장 ID는 `knbciloaffcfooifckceakenpmnljoco`다.

- `chrome-policy.example.json`: Chrome Web Store에 같은 키로 게시한 뒤 사용한다.
- `edge-policy.example.json`: Microsoft Edge Add-ons에 같은 키로 게시한 뒤 사용한다.
- 스토어 게시 전에는 상위 폴더의 `README.md`에 따라 애드인에 포함된 폴더를 압축 해제 확장으로 1회 등록한다.

예시 정책만 적용하고 스토어에 게시하지 않으면 브라우저가 확장을 내려받을 수 없다. 자체 호스팅을 선택할 경우 각 브라우저의 관리형 배포 요구사항에 맞는 서명된 CRX와 업데이트 매니페스트를 별도로 운영해야 한다.

`deployment.json`의 `disabledSelfHostedExample`은 seesumengineering 도메인을 사용할 때의 예약 주소일 뿐이며 기본값은 비활성이다. 실제 서명 CRX와 업데이트 XML을 게시하고 회사 브라우저 정책 요구사항을 확인하기 전에는 활성화하지 않는다.
