import test from "node:test";
import assert from "node:assert/strict";
import crypto from "node:crypto";
import fs from "node:fs";
import path from "node:path";
import vm from "node:vm";
import { fileURLToPath } from "node:url";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const context = vm.createContext({
  crypto: crypto.webcrypto,
  TextDecoder,
  URL,
  atob,
  setTimeout,
  clearTimeout,
  console,
});
vm.runInContext(fs.readFileSync(path.join(root, "config.js"), "utf8"), context);
vm.runInContext(fs.readFileSync(path.join(root, "bridge-core.js"), "utf8"), context);
const core = context.SEESUM_VIEWER_CORE;

const fixture = {
  payload: "eyJ0b2tlbiI6ImZpeHR1cmUtdG9rZW4iLCJleHBpcmVzVW5peFRpbWVTZWNvbmRzIjo0MTAyNDQ0ODAwLCJjb21tYW5kIjp7Im9wZXJhdGlvbiI6ImNoZWNrLWFjY291bnQiLCJmaWxlcyI6W10sImZvcmNlQWNjb3VudENob2ljZSI6ZmFsc2V9fQ",
  signature: "yJL9BZtvM16Nn0Ww5krkx9p-gdsRNTenK8eDvzJiUc7PMaPzhI3reMjwKDm81jz1TvTBcxbHZ0Dj-tPbZsUyaQ",
  algorithm: "ECDSA-P256-SHA256",
};

test("verifies a C# signed command", async () => {
  const command = await core.verifyEnvelope(fixture, "fixture-token", Date.parse("2026-07-15T00:00:00Z"));
  assert.equal(command.operation, "check-account");
});

test("rejects unsigned, changed-token, and expired commands", async () => {
  await assert.rejects(() => core.verifyEnvelope({ ...fixture, signature: fixture.signature.slice(0, -1) + "A" }, "fixture-token", Date.now()), /서명/);
  await assert.rejects(() => core.verifyEnvelope(fixture, "changed-token", Date.now()), /토큰/);
  await assert.rejects(() => core.verifyEnvelope(fixture, "fixture-token", Date.parse("2101-01-01T00:00:00Z")), /만료/);
});

test("accepts loopback connector only", () => {
  assert.equal(core.connectorToken("http://127.0.0.1:49152/connect/abc"), "abc");
  assert.throws(() => core.connectorToken("http://localhost:49152/connect/abc"), /로컬/);
  assert.throws(() => core.connectorToken("http://127.0.0.1:49152/not-connect/abc"), /주소/);
});

test("matches Viewer tabs by exact origin including port", () => {
  assert.equal(core.isViewerTabUrl("http://127.0.0.1:41000/viewer", "http://127.0.0.1:41000/viewer"), true);
  assert.equal(core.isViewerTabUrl("http://127.0.0.1:42000/connect/token", "http://127.0.0.1:41000/viewer"), false);
  assert.equal(core.isViewerTabUrl("not a url", "http://127.0.0.1:41000/viewer"), false);
});

test("waits for the exact account tab to close", async () => {
  let listener;
  const removed = {
    addListener(value) { listener = value; },
    removeListener(value) { if (listener === value) listener = undefined; },
  };
  const waiting = core.waitForTabClosed(removed, 42, 1000);
  listener(41);
  assert.equal(typeof listener, "function");
  listener(42);
  await waiting;
  assert.equal(listener, undefined);
});

test("bounds terminal reports", () => {
  assert.equal(core.validateReport({ state: "connected", message: "ok" }).state, "connected");
  assert.throws(() => core.validateReport({ state: "unknown", message: "no" }), /상태/);
  assert.throws(() => core.validateReport({ state: "failed", message: "x".repeat(2001) }), /메시지/);
});
