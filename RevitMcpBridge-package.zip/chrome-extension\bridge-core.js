(() => {
  const allowedOperations = new Set(["check-account", "connect-current", "connect-other", "upload"]);
  const allowedStates = new Set(["connected", "disconnected", "authentication-required", "uploaded", "failed"]);

  function fromBase64Url(value) {
    const base64 = value.replace(/-/g, "+").replace(/_/g, "/") + "=".repeat((4 - value.length % 4) % 4);
    return Uint8Array.from(atob(base64), character => character.charCodeAt(0));
  }

  function fromBase64(value) {
    return Uint8Array.from(atob(value), character => character.charCodeAt(0));
  }

  function connectorToken(value) {
    const url = new URL(value);
    if (url.protocol !== "http:" || url.hostname !== "127.0.0.1") throw new Error("로컬 Revit 연결만 허용합니다.");
    const parts = url.pathname.split("/").filter(Boolean);
    if (parts.length !== 2 || parts[0] !== "connect" || !parts[1]) throw new Error("잘못된 Revit 연결 주소입니다.");
    return parts[1];
  }

  function isViewerTabUrl(tabUrl, viewerUrl) {
    try { return new URL(tabUrl).origin === new URL(viewerUrl).origin; }
    catch { return false; }
  }

  async function verifyEnvelope(envelope, expectedToken, nowMilliseconds = Date.now()) {
    if (!envelope || envelope.algorithm !== "ECDSA-P256-SHA256") throw new Error("지원하지 않는 명령 서명입니다.");
    const payloadBytes = fromBase64Url(envelope.payload || "");
    const signatureBytes = fromBase64Url(envelope.signature || "");
    let payload;
    try { payload = JSON.parse(new TextDecoder().decode(payloadBytes)); }
    catch { throw new Error("Viewer 명령 payload가 손상되었습니다."); }
    if (payload.token !== expectedToken) throw new Error("Viewer 명령 토큰이 일치하지 않습니다.");
    if (!Number.isSafeInteger(payload.expiresUnixTimeSeconds) || payload.expiresUnixTimeSeconds <= Math.floor(nowMilliseconds / 1000))
      throw new Error("Viewer 명령이 만료되었습니다.");
    const publicKey = await crypto.subtle.importKey(
      "spki",
      fromBase64(SEESUM_VIEWER_CONFIG.signingPublicKeySpkiBase64),
      { name: "ECDSA", namedCurve: "P-256" },
      false,
      ["verify"]
    );
    const valid = await crypto.subtle.verify(
      { name: "ECDSA", hash: "SHA-256" },
      publicKey,
      signatureBytes,
      payloadBytes
    );
    if (!valid) throw new Error("Viewer 명령 서명을 확인할 수 없습니다.");
    return validateCommand(payload.command);
  }

  function validateCommand(command) {
    if (!command || !allowedOperations.has(command.operation)) throw new Error("지원하지 않는 Viewer 작업입니다.");
    if (!Array.isArray(command.files)) throw new Error("Viewer 파일 목록이 잘못되었습니다.");
    if (typeof command.forceAccountChoice !== "boolean") throw new Error("Viewer 계정 선택 값이 잘못되었습니다.");
    if (command.operation === "upload" && command.files.length === 0) throw new Error("선택한 RVT 파일이 없습니다.");
    if (command.files.length > 100 || command.files.some(file => typeof file !== "string" || !file.toLowerCase().endsWith(".rvt") || file.length > 1024))
      throw new Error("Viewer RVT 파일 목록이 잘못되었습니다.");
    return command;
  }

  function waitForTabClosed(onRemoved, tabId, timeoutMilliseconds) {
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        onRemoved.removeListener(listener);
        reject(new Error("Autodesk 계정 변경 시간이 초과되었습니다."));
      }, timeoutMilliseconds);
      const listener = removedTabId => {
        if (removedTabId !== tabId) return;
        clearTimeout(timer);
        onRemoved.removeListener(listener);
        resolve();
      };
      onRemoved.addListener(listener);
    });
  }

  function validateReport(report) {
    if (!report || !allowedStates.has(report.state)) throw new Error("Viewer 결과 상태가 잘못되었습니다.");
    if (typeof report.message !== "string" || !report.message.trim() || report.message.length > 2000)
      throw new Error("Viewer 결과 메시지가 잘못되었습니다.");
    if (report.failedFiles !== undefined && (!Array.isArray(report.failedFiles) || report.failedFiles.length > 100))
      throw new Error("Viewer 실패 파일 목록이 잘못되었습니다.");
    return report;
  }

  globalThis.SEESUM_VIEWER_CORE = Object.freeze({
    connectorToken,
    isViewerTabUrl,
    verifyEnvelope,
    validateCommand,
    waitForTabClosed,
    validateReport,
  });
})();
