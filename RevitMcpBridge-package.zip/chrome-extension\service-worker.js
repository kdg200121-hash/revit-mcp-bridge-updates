importScripts("config.js", "bridge-core.js");

const VIEWER_URL = SEESUM_VIEWER_CONFIG.viewerUrl;
const ACCOUNT_URL = SEESUM_VIEWER_CONFIG.accountUrl;
const CORE = SEESUM_VIEWER_CORE;
const DEBUG_VERSION = "1.3";
const NEXT_LABELS = new Set(["no more files", "파일 추가 없음", "continue", "계속", "upload", "업로드"]);
const UPLOAD_LABELS = new Set(["upload new file", "new file", "새 파일 업로드", "파일 업로드", "upload", "업로드"]);

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type !== "seesum-connect") return false;
  run(message.url, sender.tab?.id).then(
    report => sendResponse({ message: report.message }),
    error => sendResponse({ message: `연결 실패: ${safeMessage(error)}` })
  );
  return true;
});

async function run(connectorUrl, connectorTabId) {
  let report;
  try {
    const command = await fetchCommand(connectorUrl);
    if (command.operation === "connect-other") {
      const accountTab = await chrome.tabs.create({ url: ACCOUNT_URL, active: true });
      if (!accountTab.id) throw new Error("Autodesk 계정 탭을 열지 못했습니다.");
      try { await CORE.waitForTabClosed(chrome.tabs.onRemoved, accountTab.id, 240000); }
      catch (error) { throw authenticationError(error.message); }
    }
    const tab = await getOrCreateViewerTab();
    if (command.operation === "connect-other") await chrome.tabs.reload(tab.id);
    await waitForTabComplete(tab.id, 30000);
    await attach(tab.id);
    try {
      if (command.operation === "check-account") {
        const state = await snapshot(tab.id);
        report = state.authenticated
          ? { state: "connected", message: "Chrome의 Autodesk 계정에 연결되어 있습니다." }
          : { state: "disconnected", message: "Chrome에서 Autodesk 로그인이 필요합니다." };
      } else if (command.operation === "connect-current" || command.operation === "connect-other") {
        await beginOfficialLogin(tab.id);
        const state = await waitForViewerReady(tab.id, command.operation === "connect-other" ? 60000 : 300000);
        report = state.authenticated
          ? { state: "connected", message: "Autodesk 계정 연결을 확인했습니다." }
          : { state: "authentication-required", message: state.additionalAuthentication ? "브라우저에서 추가 인증을 완료하세요." : "Autodesk 로그인을 확인하지 못했습니다." };
      } else if (command.operation === "upload") {
        const files = validateFiles(command.files);
        const state = await waitForViewerReady(tab.id, 300000, true);
        if (!state.authenticated) throw authenticationError("Autodesk 계정 연결이 필요합니다.");
        await openUploadUi(tab.id);
        await registerFiles(tab.id, files);
        report = { state: "uploaded", message: `${files.length}개 파일의 Autodesk Viewer 등록을 시작했습니다.` };
      } else {
        throw new Error("지원하지 않는 Viewer 작업입니다.");
      }
    } finally {
      await detach(tab.id);
    }
  } catch (error) {
    report = { state: error?.code === "AUTHENTICATION_REQUIRED" ? "authentication-required" : "failed", message: safeMessage(error) };
  }
  await postReport(connectorUrl, report);
  if (connectorTabId) await chrome.tabs.remove(connectorTabId).catch(() => {});
  return report;
}

async function fetchCommand(connectorUrl) {
  const connector = new URL(connectorUrl);
  const token = CORE.connectorToken(connectorUrl);
  const response = await fetch(`${connector.origin}/api/${encodeURIComponent(token)}/command`, { method: "POST", cache: "no-store" });
  if (!response.ok) throw new Error(`Revit 연결 명령 오류 (${response.status})`);
  return await CORE.verifyEnvelope(await response.json(), token);
}

async function getOrCreateViewerTab() {
  const tabs = await chrome.tabs.query({});
  const viewerTab = tabs.find(tab => CORE.isViewerTabUrl(tab.url || "", VIEWER_URL));
  if (viewerTab) {
    await chrome.tabs.update(viewerTab.id, { active: true });
    return viewerTab;
  }
  return await chrome.tabs.create({ url: VIEWER_URL, active: true });
}

async function waitForTabComplete(tabId, timeoutMs) {
  await new Promise((resolve, reject) => {
    const timer = setTimeout(() => {
      chrome.tabs.onUpdated.removeListener(listener);
      reject(new Error("Autodesk Viewer 페이지 로딩 시간이 초과되었습니다."));
    }, timeoutMs);
    const listener = (updatedId, changeInfo) => {
      if (updatedId !== tabId || changeInfo.status !== "complete") return;
      clearTimeout(timer);
      chrome.tabs.onUpdated.removeListener(listener);
      resolve();
    };
    chrome.tabs.onUpdated.addListener(listener);
    chrome.tabs.get(tabId).then(tab => {
      if (tab.status !== "complete") return;
      clearTimeout(timer);
      chrome.tabs.onUpdated.removeListener(listener);
      resolve();
    }, error => {
      clearTimeout(timer);
      chrome.tabs.onUpdated.removeListener(listener);
      reject(error);
    });
  });
}

async function attach(tabId) {
  await chrome.debugger.attach({ tabId }, DEBUG_VERSION);
  await send(tabId, "Page.enable");
  await send(tabId, "DOM.enable");
  await send(tabId, "Runtime.enable");
}

async function detach(tabId) {
  try { await chrome.debugger.detach({ tabId }); } catch { }
}

async function snapshot(tabId) {
  const allowedHosts = JSON.stringify(SEESUM_VIEWER_CONFIG.allowedViewerHosts);
  const expression = `(() => {
    const url = location.href;
    const allowedHosts = ${allowedHosts};
    const hostAllowed = allowedHosts.some(host => location.hostname === host || location.hostname.endsWith('.' + host));
    const text = (document.body?.innerText || "").toLowerCase();
    const fileInput = !!document.querySelector('input[type="file"]');
    const authenticated = hostAllowed && (fileInput || /designviews|upload/.test(location.pathname) || /new file|새 파일|내 설계|my designs/.test(text));
    const loginRequired = /로그인|sign in/.test(text) && !authenticated;
    const additionalAuthentication = /verification code|security code|2단계|인증 코드|captcha|single sign-on|sso/.test(text);
    return { url, hostAllowed, fileInput, authenticated, loginRequired, additionalAuthentication };
  })()`;
  const result = await send(tabId, "Runtime.evaluate", { expression, returnByValue: true });
  return result?.result?.value || {};
}

async function beginOfficialLogin(tabId) {
  const state = await snapshot(tabId);
  if (state.authenticated) return;
  await send(tabId, "Runtime.evaluate", {
    expression: `(() => { const button = document.querySelector('#app_login') || [...document.querySelectorAll('[role="button"],button,a')].find(x => /^(로그인|sign in)$/i.test((x.innerText || x.textContent || '').trim())); if (button) button.click(); })()`,
  });
}

async function waitForViewerReady(tabId, timeoutMs, stopOnAuthenticationRequired = false) {
  const deadline = Date.now() + timeoutMs;
  let last = {};
  while (Date.now() < deadline) {
    last = await snapshot(tabId);
    if (last.authenticated) return last;
    if (stopOnAuthenticationRequired && (last.loginRequired || last.additionalAuthentication)) return last;
    await delay(1000);
  }
  return last;
}

async function openUploadUi(tabId) {
  let state = await snapshot(tabId);
  if (state.fileInput) return;
  const labels = JSON.stringify([...UPLOAD_LABELS]);
  await send(tabId, "Runtime.evaluate", {
    expression: `(() => { const allowed = new Set(${labels}); const visible = e => !!(e.offsetWidth || e.offsetHeight || e.getClientRects().length); const candidates = [...document.querySelectorAll('button,[role="button"],a')].filter(visible).filter(e => allowed.has((e.innerText || e.getAttribute('aria-label') || '').trim().toLowerCase())); if (candidates.length === 1) { candidates[0].click(); return true; } return false; })()`,
  });
  const deadline = Date.now() + 30000;
  while (Date.now() < deadline) {
    state = await snapshot(tabId);
    if (state.fileInput) return;
    await delay(500);
  }
  throw new Error("Viewer 파일 업로드 화면을 열지 못했습니다.");
}

async function registerFiles(tabId, files) {
  const document = await send(tabId, "DOM.getDocument", { depth: -1, pierce: true });
  const found = await send(tabId, "DOM.querySelector", { nodeId: document.root.nodeId, selector: 'input[type="file"]' });
  if (!found.nodeId) throw new Error("Viewer 파일 선택 영역을 찾지 못했습니다.");
  await send(tabId, "DOM.setFileInputFiles", { nodeId: found.nodeId, files });
  const selected = await send(tabId, "Runtime.evaluate", {
    expression: `(() => { const input = document.querySelector('input[type="file"]'); if (!input) return -1; input.dispatchEvent(new Event('input',{bubbles:true})); input.dispatchEvent(new Event('change',{bubbles:true})); return input.files?.length ?? -1; })()`,
    returnByValue: true,
  });
  if (selected?.result?.value !== files.length) throw new Error("Viewer에 선택한 파일이 모두 등록되지 않았습니다.");
  await delay(1000);
  const labels = JSON.stringify([...NEXT_LABELS]);
  const clicked = await send(tabId, "Runtime.evaluate", {
    expression: `(() => { const allowed = new Set(${labels}); const visible = e => !!(e.offsetWidth || e.offsetHeight || e.getClientRects().length); const candidates = [...document.querySelectorAll('button,[role="button"]')].filter(visible).filter(e => allowed.has((e.innerText || e.getAttribute('aria-label') || '').trim().toLowerCase())); if (candidates.length === 1) { candidates[0].click(); return true; } return false; })()`,
    returnByValue: true,
  });
  await waitForUploadAcknowledgement(tabId, files, 60000, clicked?.result?.value === true);
}

async function waitForUploadAcknowledgement(tabId, files, timeoutMs, clicked) {
  const names = files.map(file => file.split(/[\\/]/).pop().toLowerCase());
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    const expression = `(() => { const text = (document.body?.innerText || '').toLowerCase(); const names = ${JSON.stringify(names)}; const fileInput = !!document.querySelector('input[type="file"]'); const namesVisible = names.every(name => text.includes(name)); const processing = /uploading|processing|업로드 중|처리 중/.test(text); return { error: /upload failed|업로드 실패|처리 실패|오류가 발생/.test(text), acknowledged: namesVisible && (processing || !fileInput) }; })()`;
    const result = await send(tabId, "Runtime.evaluate", { expression, returnByValue: true });
    const state = result?.result?.value || {};
    if (state.error) throw new Error("Autodesk Viewer가 파일 등록 오류를 표시했습니다.");
    if (state.acknowledged) return;
    await delay(1000);
  }
  if (!clicked) throw new Error("Viewer 다음 또는 업로드 버튼을 찾지 못했습니다.");
  throw new Error("Autodesk Viewer에서 파일 등록 시작을 확인하지 못했습니다.");
}

async function postReport(connectorUrl, report) {
  const connector = new URL(connectorUrl);
  const token = CORE.connectorToken(connectorUrl);
  CORE.validateReport(report);
  const response = await fetch(`${connector.origin}/api/${encodeURIComponent(token)}/report`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(report),
    cache: "no-store",
  });
  if (!response.ok) throw new Error(`Revit 결과 전송 오류 (${response.status})`);
}

function validateFiles(files) {
  if (!Array.isArray(files) || files.length === 0) throw new Error("선택된 RVT 파일이 없습니다.");
  if (files.some(file => typeof file !== "string" || !file.toLowerCase().endsWith(".rvt"))) throw new Error("RVT 파일만 등록할 수 있습니다.");
  return files;
}

function authenticationError(message) {
  const error = new Error(message || "Autodesk 계정 인증이 필요합니다.");
  error.code = "AUTHENTICATION_REQUIRED";
  return error;
}

function send(tabId, method, params = {}) {
  return chrome.debugger.sendCommand({ tabId }, method, params);
}

function delay(milliseconds) {
  return new Promise(resolve => setTimeout(resolve, milliseconds));
}

function safeMessage(error) {
  return error instanceof Error ? error.message : "알 수 없는 Viewer 오류입니다.";
}
