# SEESUM Autodesk Viewer Bridge

Chrome 확장 프로그램 관리 화면에서 개발자 모드를 켜고 이 폴더를 `압축해제된 확장 프로그램을 로드합니다`로 선택한다. 확장은 Revit 애드인의 127.0.0.1 일회성 연결과 Autodesk Viewer 탭에서만 동작한다.

고정 확장 ID는 `knbciloaffcfooifckceakenpmnljoco`이며 Revit 브리지는 이 ID에서 온 요청만 허용한다. 애드인의 계정 연결 창에서 `Chrome 확장 설치`를 누르면 확장 관리 화면과 설치 폴더가 열린다.

다른 PC에서도 애드인 설치 폴더의 `chrome-extension` 폴더를 같은 방식으로 1회 등록하면 된다. 확장 ID와 서명 검증 키는 고정되어 있어 PC가 달라도 Revit 브리지와 일치한다. 회사에서 일괄 설치하려면 `managed-policy`의 예시와 안내를 사용하되, 먼저 동일 키로 Chrome Web Store 또는 Microsoft Edge Add-ons에 게시해야 한다.

`deployment.json`에는 배포 버전, 고정 확장 ID, 핵심 파일 SHA-256이 들어 있다. 패키지 검증은 이 값을 다시 계산해 변조나 누락을 차단한다. Revit 계정 토큰이나 Autodesk 비밀번호는 확장 프로그램으로 전달되지 않는다.
